package net.minheur.potoflux.translations.register;

import net.minheur.potoflux.PotoFlux;
import net.minheur.potoflux.screen.tabs.Tabs;
import net.minheur.potoflux.terminal.commands.Commands;
import net.minheur.potoflux.translations.AbstractTranslationsRegistry;

/**
 * Registry for all potoflux translations
 */
public class PotoFluxTranslations extends AbstractTranslationsRegistry {
    /**
     * Calls the constructor to set the modID
     */
    public PotoFluxTranslations() {
        super(PotoFlux.ID);
    }

    /**
     * Actually add translation
     */
    @Override
    protected void makeTranslation() {
        // commands
        addCommand("ascii")
                .en("Show an ASCII")
                .fr("Affiche un ASCII");
        addCommandUse("ascii")
                .en("Usage: ascii")
                .fr("Utilisation : ascii");
        addCommandUse("ascii","choose")
                .en("Usage: ascii <name>")
                .fr("Utilisation : ascii <nom>");

        addCommand("clear")
                .en("Clears the terminal")
                .fr("Vide le terminal");
        addCommandUse("clear")
                .en("Usage: clear")
                .fr("Utilisation : clear");

        addCommand("version")
                .en("Get actual PotoFlux version")
                .fr("Affiche la version actuelle de PotoFLux");
        addCommandUse("version")
                .en("Usage: version")
                .fr("Utilisation : version");

        addCommand("echo")
                .en("Repeats what you give")
                .fr("Répète ce que vous écrivez");
        addCommandUse("echo")
                .en("Usage: echo <text>")
                .fr("Utilisation : echo <texte>");

        addCommand("hello_world")
                .en("Says hello world")
                .fr("Dit hello world");
        addCommandUse("hello_world")
                .en("Usage: hello")
                .fr("Utilisation : hello");

        addCommand("help")
                .en("Shows this menu")
                .fr("Affiche ce menu");
        addCommand("help", "title")
                .en("Command list:")
                .fr("Liste des commandes :");
        addCommandUse("help")
                .en("Usage: help")
                .fr("Utilisation : help");
        addCommandUse("help", "command")
                .en("Usage: help <command>")
                .fr("Utilisation : help <commande>");

        addCommand("hidden", "out")
                .en("Hidden command :)")
                .fr("Commande caché ;)");

        addCommand("nope", "out")
                .en("I got you !")
                .fr("CHEH");

        addCommand("quit")
                .en("Exits app")
                .fr("Ferme l'app");
        addCommand("quit", "out")
                .en("Exiting...")
                .fr("Fermeture...");
        addCommandUse("quit")
                .en("Usage: quit")
                .fr("Utilisation : quit");

        addCommand("source")
                .en("Link to source code")
                .fr("Lien vers le code source");
        addCommand("source", "out")
                .en("Opened code source in browser !")
                .fr("Code source ouvert dans le navigateur !");
        addCommand("source", "noBrowse")
                .en("Could not open source code ! Here is the link:")
                .fr("Impossible d'ouvrir le code source dans le navigateur. Voici le lien :");
        addCommandUse("source")
                .en("Usage: source-code")
                .fr("Utilisation : source-code");

        addCommand("tab")
                .en("Open given tab")
                .fr("Ouvre l'onglet donné");
        addCommand("tab", "null")
                .en("Tab $$1 doesn't exists !")
                .fr("L'onglet $$1 n'existe pas !");
        addCommand("tab", "opened")
                .en("This tab is already opened !")
                .fr("Cet onglet est déjà ouvert !");
        addCommandUse("tab")
                .en("Usage: tab <tabResourceLoc>")
                .fr("Utilisation : tab <ressourceLocDeLaTab>");

        addCommand("listTab")
                .en("Lists all the tabs")
                .fr("Liste touts les onglets");
        addCommand("listTab", "intro")
                .en("Here is all the tabs: ")
                .fr("Voici touts les onglets : ");
        addCommandUse("listTab")
                .en("Usage: tabList")
                .fr("Utilisation : tabList");
        addCommandUse("listTab", "resourceLoc")
                .en("Usage: tabList --resourceLoc")
                .fr("Utilisation : tabList --resourceLoc");

        addCommand("time")
                .en("Tells the time")
                .fr("Dit le temps (très précis)");
        addCommandUse("time")
                .en("Usage: time")
                .fr("Utilisation : time");

        addCommand("modList")
                .en("Lists you loaded mods")
                .fr("Liste tous les mods chargé (activés)");
        addCommandUse("modList")
                .en("Usage: modList")
                .fr("Utilisation : modList");

        addCommand("modDir")
                .en("Open mod directory")
                .fr("Ouvre le dossier des mods");
        addCommandUse("modDir")
                .en("Usage: modDir")
                .fr("Utilisation : modDir");

        addCommandPro("empty")
                .en("Could not execute empty command !")
                .fr("Impossible d'exécuter une commande vide !");
        addCommandPro("none")
                .en("Command not recognized ! Try \"help\" !")
                .fr("Commande non reconnu ! Essayez \"help\" !");

        addPref("reload")
                .en("Please restart PotoFlux to apply.")
                .fr("Merci de redémarrer PotoFlux, afin d'appliquer.");
        addPref("ascii")
                .en("ASCII")
                .fr("ASCII");
        addPref("ascii", "select")
                .en("Select terminal ASCII")
                .fr("Choisissez un ASCII du terminal");
        addPref("ascii", "button")
                .en("Change terminal ASCII")
                .fr("Changer l'ASCII du terminal");
        addPref("lang")
                .en("Language")
                .fr("Langue");
        addPref("lang", "select")
                .en("Select language")
                .fr("Sélectionnez la langue");
        addPref("lang", "button")
                .en("Change language")
                .fr("Changer la langue");
        addPref("theme")
                .en("Theme")
                .fr("Thème");
        addPref("theme", "select")
                .en("Select new theme")
                .fr("Sélectionnez le nouveau thème");
        addPref("theme", "button")
                .en("Change theme")
                .fr("Changer le thème");

        addScreen("tabHereNotHere")
                .en("ERROR: this tab is detected but unexisting !")
                .fr("Erreur : cette onglet est détecté mais inéxistante !");

        addHomeTab("credit")
                .en("Created by Min_heur2000 - TechnoMastery")
                .fr("Créé par Min_heur2000 - TechnoMastery");
        addHomeTab("name")
                .en("Home")
                .fr("Home");
        addHomeTab("title")
                .en("Potoflux - Home")
                .fr("Potoflux - Home");
        addHomeTab("version")
                .en("PotoFlux in version $$1")
                .fr("PotoFlux en version $$1");

        addSettingsTab("name")
                .en("Settings")
                .fr("Paramètres");

        addTerminalTab("name")
                .en("Terminal")
                .fr("Terminal");

        add("modUpdate", "query", "compatible")
                .en("The mod $$1 has an available update: $$2 to $$3.\nDo you want to download it ?")
                .fr("Le mod $$1 a une mise a jour disponible : $$2 vers $$3.\nVoulez-vous l'installer ?");
        add("modUpdate", "query", "notCompatible")
                .en("The mod $$1 is incompatible ! However, it's version $$2 is.\nDo you want to download it ?")
                .fr("Le mod $$1 est incompatible ! Cependant, sa version $$2 l'est.\nVoulez-vous l'installer ?");

        add("modUpdate", "dl", "noLink")
                .en("There are no install link set !\nPlease contact the mod owner.")
                .fr("Aucuns lien d'installation défini !\nRéferez vous au développeur du mod.");
        add("modUpdate", "dl", "noLink", "title")
                .en("No install link")
                .fr("Lien d'installation manquant");

        add("modUpdate", "dl", "failed")
                .en("Failed to open install link in browser !")
                .fr("Nous n'avons pas pu ouvrir le lien d'installation dans votre navigateur.");
        add("modUpdate", "dl", "failed", "title")
                .en("Browsing failed")
                .fr("La navigation a échoué");
    }

    /**
     * Add a translation for the command processor
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addCommandPro(String... children) {
        return add("commandPro", children);
    }
    /**
     * Add a translation for the preferences
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addPref(String... children) {
        return add("prefs", children);
    }
    /**
     * Add a translation for the screen
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addScreen(String... children) {
        return add("screen", children);
    }

    // tabs helpers
    /**
     * Add a translation for the home tab
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addHomeTab(String... children) {
        return addTab("home", children);
    }
    /**
     * Add a translation for the settings tab
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addSettingsTab(String... children) {
        return addTab("settings", children);
    }
    /**
     * Add a translation for the terminal tab
     * @param children optional extra members
     * @return the translation builder associated
     */
    private TranslationBuilder addTerminalTab(String... children) {
        return addTab("terminal", children);
    }
}

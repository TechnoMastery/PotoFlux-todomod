package net.minheur.potoflux.screen;

import net.minheur.potoflux.PotoFlux;
import net.minheur.potoflux.loader.PotoFluxLoadingContext;
import net.minheur.potoflux.screen.tabs.TabRegistry;
import net.minheur.potoflux.screen.tabs.BaseTab;
import net.minheur.potoflux.screen.tabs.Tab;
import net.minheur.potoflux.translations.Translations;
import net.minheur.potoflux.logger.LogCategories;
import net.minheur.potoflux.logger.PtfLogger;
import net.minheur.potoflux.utils.ressourcelocation.ResourceLocation;

import javax.annotation.Nonnull;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.*;
import java.util.List;

/**
 * The handler for the main potoflux screen
 */
public class PotoScreen {
    /**
     * The actual {@link JFrame} for the class
     */
    private final JFrame frame;
    /**
     * The map containing the tabs, by there tab item and the tab class
     */
    private final Map<Tab, BaseTab> tabMap = new HashMap<>();
    /**
     * Swing element added to the {@link #frame}, containing all added tabs
     */
    private final JTabbedPane tabs = new JTabbedPane(JTabbedPane.LEFT);

    /**
     * Constructor for creating the screen
     */
    public PotoScreen() {
        frame = setupFrame();

        addIcon();
        addPanels();

        frame.setVisible(true);
    }

    @Nonnull
    private JFrame setupFrame() {
        final JFrame frame;
        frame = new JFrame("PotoFlux");
        frame.setSize(854, 512);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                PotoFlux.runProgramClosing(0);
            }
        });
        frame.setLocationRelativeTo(null);

        Properties optionalFeatures = PotoFluxLoadingContext.getOptionalFeatures();
        boolean isResizable = Boolean.parseBoolean(optionalFeatures.getProperty("resizableWindow", "false"));
        if (!isResizable) frame.setResizable(false);
        return frame;
    }

    /**
     * Handle the adding part of the tabs and mod tabs to the {@link #tabs}
     */
    private void addPanels() {
        tabs.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        List<Tab> allTabs = TabRegistry.getAll().stream() // get all tabs
                .sorted(Comparator.comparing( // compare
                        tab -> !tab.id().getNamespace().equals(PotoFlux.ID) // true → added after
                ))
                .toList();

        // register all tabs in ones
        fillTabMap(allTabs);

        frame.add(tabs);
    }

    private void fillTabMap(List<Tab> allTabs) {
        for (Tab tabType : allTabs) {
            BaseTab instance = tabType.createInstance();
            if (instance != null) {
                tabs.add(tabType.name(), instance.getPanel());
                tabMap.put(tabType, instance);
            }
        }
    }

    /**
     * Adds the potoflux icon to the {@link #frame}
     */
    private void addIcon() {
        Image icon600 = new ImageIcon(Objects.requireNonNull(getClass().getResource("/textures/main.png"))).getImage();
        List<Image> icons = new ArrayList<>();
        icons.add(icon600.getScaledInstance(16, 16, Image.SCALE_SMOOTH));
        icons.add(icon600.getScaledInstance(32, 32, Image.SCALE_SMOOTH));
        icons.add(icon600.getScaledInstance(64, 64, Image.SCALE_SMOOTH));
        frame.setIconImages(icons);
    }

    /**
     * Getter for the {@link #tabMap}
     * @return the {@link #tabMap}
     */
    public Map<Tab, BaseTab> getTabMap() {
        return tabMap;
    }
    /**
     * Gets the tab from its resource location
     * @param loc the loc to get the tab from
     * @return the corresponding tab class
     */
    public BaseTab getFromResourceLoc(ResourceLocation loc) {
        for (Map.Entry<Tab, BaseTab> entry : tabMap.entrySet())
            if (entry.getKey().id().equals(loc)) return entry.getValue();

        PtfLogger.error("Accessing unexisting tab: " + loc.toString(), LogCategories.SCREEN);
        return null;
    }

    /**
     * Getter for the {@link #frame}
     * @return the {@link #frame}
     */
    public JFrame getFrame() {
        return frame;
    }

    /**
     * Sets the opened tab in the app.
     * @param tab the tab to be set in the {@link #tabs}
     */
    public void setOpenedTab(Tab tab) {
        if (!tabMap.containsKey(tab)) {
            JOptionPane.showMessageDialog(frame, Translations.get("potoflux:screen.tabHereNotHere"));
            return;
        }
        tabs.setSelectedComponent(tabMap.get(tab).getPanel());
    }
}
